import json
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report


DATA_PATH = "default of credit card clients.xls"
MODEL_PATH = "model.pkl"
FEATURES_PATH = "feature_columns.json"


def load_data(path: str) -> pd.DataFrame:
  # In your notebook you used header=1 because first row is description
  df = pd.read_excel(path, header=1)
  # Rename target to a simpler name
  df = df.rename(columns={"default payment next month": "IsDefaulter"})
  return df


def build_dataset(df: pd.DataFrame):
  # Use the same raw columns as in the original dataset (except ID)
  feature_columns = [
    "LIMIT_BAL",
    "SEX",
    "EDUCATION",
    "MARRIAGE",
    "AGE",
    "PAY_0",
    "PAY_2",
    "PAY_3",
    "PAY_4",
    "PAY_5",
    "PAY_6",
    "BILL_AMT1",
    "BILL_AMT2",
    "BILL_AMT3",
    "BILL_AMT4",
    "BILL_AMT5",
    "BILL_AMT6",
    "PAY_AMT1",
    "PAY_AMT2",
    "PAY_AMT3",
    "PAY_AMT4",
    "PAY_AMT5",
    "PAY_AMT6",
  ]

  X = df[feature_columns].values.astype(np.float32)
  y = df["IsDefaulter"].values.astype(int)

  return X, y, feature_columns


def train_and_save():
  print("Loading data from:", DATA_PATH)
  df = load_data(DATA_PATH)

  print("Building dataset...")
  X, y, feature_columns = build_dataset(df)

  X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
  )

  print("Training RandomForestClassifier...")
  clf = RandomForestClassifier(
    n_estimators=200,
    max_depth=20,
    n_jobs=-1,
    random_state=42,
  )
  clf.fit(X_train, y_train)

  print("Evaluating on test set...")
  y_pred = clf.predict(X_test)
  print(classification_report(y_test, y_pred))

  print(f"Saving model to {MODEL_PATH} ...")
  joblib.dump(clf, MODEL_PATH)

  print(f"Saving feature columns to {FEATURES_PATH} ...")
  with open(FEATURES_PATH, "w", encoding="utf-8") as f:
    json.dump(feature_columns, f, indent=2)

  print("Done.")


if __name__ == "__main__":
  train_and_save()


