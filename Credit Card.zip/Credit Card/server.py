import json
from pathlib import Path

import joblib
import numpy as np
from flask import Flask, send_from_directory, request, jsonify

MODEL_PATH = Path("model.pkl")
FEATURES_PATH = Path("feature_columns.json")

app = Flask(__name__, static_folder=".", static_url_path="")


def load_model_and_features():
  if not MODEL_PATH.exists() or not FEATURES_PATH.exists():
    return None, None

  model = joblib.load(MODEL_PATH)
  with FEATURES_PATH.open("r", encoding="utf-8") as f:
    feature_columns = json.load(f)
  return model, feature_columns


model, feature_columns = load_model_and_features()


@app.route("/")
def index():
  # Serve the main frontend page
  return send_from_directory(".", "index.html")


@app.route("/predict", methods=["POST"])
def predict():
  """
  Real prediction endpoint using trained model (if available).
  """
  global model, feature_columns

  if model is None or feature_columns is None:
    return jsonify({"error": "Model not trained yet. Run train_model.py first."}), 500

  data = request.get_json(force=True) or {}

  # Build feature vector in the exact column order used during training
  features = []
  for col in feature_columns:
    val = data.get(col, 0)
    try:
      val = float(val)
    except (TypeError, ValueError):
      val = 0.0
    features.append(val)

  X = np.array(features, dtype=np.float32).reshape(1, -1)

  # Predict probability of default (class 1)
  probs = model.predict_proba(X)[0]
  prob_default = float(probs[1])
  will_default = prob_default >= 0.5

  return jsonify(
    {
      "default_probability": prob_default,
      "will_default": will_default,
    }
  )


if __name__ == "__main__":
  app.run(host="127.0.0.1", port=5000, debug=True)



